# PlagScanner-X : Plagiarism Detector Tool
We are a team of Anti-Cheating Squad. Be aware!!

Tech Stack: Python for ML Algorithms, flask, beautifulsoup4, HTML, CSS, JavaScript.


![1](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/a4ab6a9b-3edf-45f3-95a8-e99c1274988f)


![2](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/21d21bdf-6498-4eb9-a61c-d6bd3c191f4d)


![3](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/74a82718-a934-4c49-92b8-27d240f77734)


![4](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/b109f496-df33-4f17-9dc0-f3b5f98fc767)


![5](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/aabe4bf7-388a-4d86-bd65-6809134df153)


![6](https://github.com/prathameshursal/PlagScanner-X/assets/101964034/77b706e5-27e5-4ed3-897f-da11abaf9554)
